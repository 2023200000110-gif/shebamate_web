function syncProviderRegistrationRequirements() {
  const provider = document.querySelector('.role-tab.active')?.dataset.role === 'provider';
  const registering = document.querySelector('.auth-mode.active')?.dataset.mode === 'register';
  const location = document.querySelector('#locationField input');
  const category = document.querySelector('#categoryField select');
  if (!location || !category) return;
  location.required = provider && registering;
  category.required = provider && registering;
  location.setAttribute('aria-required', String(provider && registering));
  category.setAttribute('aria-required', String(provider && registering));
}

document.querySelectorAll('.role-tab, .auth-mode').forEach((control) => control.addEventListener('click', () => setTimeout(syncProviderRegistrationRequirements, 0)));
document.addEventListener('DOMContentLoaded', syncProviderRegistrationRequirements);
syncProviderRegistrationRequirements();
