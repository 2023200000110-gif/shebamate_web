function addProviderAvailabilitySave() {
  const checkbox = document.querySelector('#providerAvailability');
  const toggle = checkbox?.closest('.availability-toggle');
  if (!checkbox || !toggle || document.querySelector('#saveAvailability')) return;
  const save = document.createElement('button');
  save.id = 'saveAvailability';
  save.className = 'button button-dark availability-save';
  save.type = 'button';
  save.textContent = 'Save availability';
  toggle.after(save);
  save.addEventListener('click', async () => {
    save.disabled = true;
    save.textContent = 'Saving...';
    try {
      const response = await fetch('/api/provider/profile', { method: 'PATCH', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('shebamate_token') || ''}` }, body: JSON.stringify({ available: checkbox.checked }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Could not save availability.');
      toggle.querySelector('strong').textContent = data.available ? 'Accepting jobs' : 'Paused';
      const toast = document.querySelector('#toast');
      toast.textContent = data.available ? 'Availability saved: accepting jobs.' : 'Availability saved: paused.';
      toast.classList.add('show');
      setTimeout(() => toast.classList.remove('show'), 2500);
    } catch (error) {
      const toast = document.querySelector('#toast');
      toast.textContent = error.message;
      toast.classList.add('show');
      setTimeout(() => toast.classList.remove('show'), 2500);
    } finally {
      save.disabled = false;
      save.textContent = 'Save availability';
    }
  });
}

new MutationObserver(addProviderAvailabilitySave).observe(document.body, { childList: true, subtree: true });
addProviderAvailabilitySave();

async function showProviderApprovalState() {
  const checkbox = document.querySelector('#providerAvailability');
  const card = checkbox?.closest('.provider-availability-card');
  if (!checkbox || !card) return;
  const response = await fetch('/api/provider/profile', { headers: { Authorization: `Bearer ${localStorage.getItem('shebamate_token') || ''}` } });
  if (!response.ok) return;
  const profile = await response.json();
  if (profile.verified === false) {
    if (card.querySelector('.approval-note')) return;
    checkbox.disabled = true;
    const save = document.querySelector('#saveAvailability');
    if (save) save.disabled = true;
    const note = document.createElement('p');
    note.className = 'approval-note';
    note.textContent = 'Admin approval is required before you can accept customer bookings.';
    card.querySelector('div').append(note);
  }
}
new MutationObserver(showProviderApprovalState).observe(document.body, { childList: true, subtree: true });
showProviderApprovalState();
