# ShebaMate

A premium service marketplace built with vanilla HTML, CSS, JavaScript, Express, and MongoDB.

## Run locally

```bash
npm install
copy .env.example .env
npm start
```

Open http://localhost:3000.

## Demo accounts

- Customer: `customer@shebamate.com` / `customer123`
- Provider: `provider@shebamate.com` / `provider123`
- Admin: `admin@shebamate.com` / `admin123`

Set `MONGODB_URI` in `.env` to a local MongoDB instance or a MongoDB Atlas connection string. When configured, ShebaMate automatically creates the collections and seeds demo records once. Without it, the app runs in demo memory mode and data resets when the server restarts.

For production, replace demo password storage with bcrypt or Argon2 hashing, use a persistent session store, add rate limiting, and configure payment, file upload, phone, and notification providers.
