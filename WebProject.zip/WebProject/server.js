﻿const express = require('express');
const path = require('path');
const crypto = require('crypto');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;
const sessions = new Map();
const demoUsers = [
  { id: 'cus-1001', name: 'Aarav Sharma', email: 'customer@shebamate.com', password: 'customer123', role: 'customer', location: 'Banani, Dhaka' },
  { id: 'pro-2001', name: 'Nadia Rahman', email: 'provider@shebamate.com', password: 'provider123', role: 'provider', location: 'Gulshan, Dhaka', category: 'Electrician', verified: true },
  { id: 'adm-3001', name: 'ShebaMate Admin', email: 'admin@shebamate.com', password: 'admin123', role: 'admin' }
];
const demoCategories = ['Electrician', 'Plumber', 'Driver', 'Tutor', 'Maid/Cleaner'];
const demoProviders = [
  { id: 'pro-2001', name: 'Nadia Rahman', category: 'Electrician', location: 'Gulshan, Dhaka', rating: 4.9, experience: '8 years', price: 'From à§³800', available: true, initials: 'NR', color: 'coral', verified: true, bio: 'Certified residential electrician for safe repairs, wiring, and appliance installations.' },
  { id: 'pro-2002', name: 'Imran Hossain', category: 'Plumber', location: 'Dhanmondi, Dhaka', rating: 4.8, experience: '6 years', price: 'From à§³650', available: true, initials: 'IH', color: 'blue', verified: true, bio: 'Fast, tidy plumbing support for leaks, fittings, bathrooms, and kitchen lines.' },
  { id: 'pro-2003', name: 'Maliha Noor', category: 'Tutor', location: 'Uttara, Dhaka', rating: 4.7, experience: '5 years', price: 'From à§³500', available: false, initials: 'MN', color: 'gold', verified: true, bio: 'Friendly math and English tutor for school learners and exam preparation.' },
  { id: 'pro-2004', name: 'Rafiq Ahmed', category: 'Driver', location: 'Mohakhali, Dhaka', rating: 4.6, experience: '10 years', price: 'From à§³900', available: true, initials: 'RA', color: 'green', verified: true, bio: 'Professional city driver with a clean vehicle and flexible hourly bookings.' }
];
const demoBookings = [
  { id: 'BK-4821', customerId: 'cus-1001', providerId: 'pro-2001', provider: 'Nadia Rahman', category: 'Electrician', date: '2026-09-18', time: '10:30 AM', location: 'Banani, Dhaka', status: 'Confirmed', amount: 1200 }
];
const demoNotifications = [];
const demoReviews = [];

const userSchema = new mongoose.Schema({ id: { type: String, unique: true }, name: String, email: { type: String, unique: true, lowercase: true, trim: true }, password: String, role: { type: String, enum: ['customer', 'provider', 'admin'] }, location: String, category: String, verified: Boolean }, { timestamps: true });
const providerSchema = new mongoose.Schema({ id: { type: String, unique: true }, name: String, category: String, location: String, rating: Number, experience: String, price: String, available: Boolean, initials: String, color: String, verified: Boolean, bio: String }, { timestamps: true });
const bookingSchema = new mongoose.Schema({ id: { type: String, unique: true }, customerId: String, providerId: String, provider: String, category: String, date: String, time: String, location: String, details: String, status: String, amount: Number }, { timestamps: true });
const notificationSchema = new mongoose.Schema({ id: { type: String, unique: true }, recipientId: String, actorId: String, type: String, title: String, message: String, entityId: String, read: { type: Boolean, default: false } }, { timestamps: true });
const reviewSchema = new mongoose.Schema({ id: { type: String, unique: true }, bookingId: String, customerId: String, customer: String, providerId: String, rating: Number, comment: String }, { timestamps: true });
const categorySchema = new mongoose.Schema({ name: { type: String, unique: true } });
const User = mongoose.model('User', userSchema);
const Provider = mongoose.model('Provider', providerSchema);
const Booking = mongoose.model('Booking', bookingSchema);
const Notification = mongoose.model('Notification', notificationSchema);
const Review = mongoose.model('Review', reviewSchema);
const Category = mongoose.model('Category', categorySchema);
let databaseMode = 'demo';
let users = demoUsers;
let providers = demoProviders;
let bookings = demoBookings;
let categories = demoCategories;
let notifications = demoNotifications;
let reviews = demoReviews;

async function connectDatabase() {
  if (!process.env.MONGODB_URI) {
    console.warn('MONGODB_URI is not set. Running in demo memory mode.');
    return;
  }
  await mongoose.connect(process.env.MONGODB_URI);
  databaseMode = 'mongodb';
  if (await User.countDocuments() === 0) await User.insertMany(demoUsers);
  if (await Provider.countDocuments() === 0) await Provider.insertMany(demoProviders);
  if (await Category.countDocuments() === 0) await Category.insertMany(demoCategories.map((name) => ({ name })));
  if (await Booking.countDocuments() === 0) await Booking.insertMany(demoBookings);
  console.log('MongoDB connected. Persistent mode enabled.');
}

async function collections() {
  if (databaseMode === 'mongodb') return { users: User, providers: Provider, bookings: Booking, categories: Category, notifications: Notification, reviews: Review };
  return { users: null, providers: null, bookings: null, categories: null, notifications: null, reviews: null };
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
async function addNotification({ recipientId, actorId, type, title, message, entityId }) {
  const notification = { id: `NT-${Date.now()}-${Math.floor(Math.random() * 1000)}`, recipientId, actorId, type, title, message, entityId, read: false };
  const models = await collections();
  if (models.notifications) await models.notifications.create(notification); else notifications.unshift(notification);
  return notification;
}
async function notifyAdmins(payload) {
  const models = await collections();
  const admins = models.users ? await User.find({ role: 'admin' }).select('id').lean() : users.filter((user) => user.role === 'admin');
  await Promise.all(admins.map((admin) => addNotification({ ...payload, recipientId: admin.id })));
}

function publicUser(user) {
  const { password, ...safeUser } = user;
  return safeUser;
}
async function auth(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const userId = sessions.get(token);
  const models = await collections();
  const user = models.users ? await models.users.findOne({ id: userId }).lean() : users.find((item) => item.id === userId);
  if (!user) return res.status(401).json({ message: 'Please sign in to continue.' });
  req.user = user;
  next();
}

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'ShebaMate API', database: databaseMode }));
app.get('/api/categories', async (req, res) => {
  const models = await collections();
  const result = models.categories ? (await models.categories.find().sort({ name: 1 }).lean()).map((item) => item.name) : categories;
  res.json(result);
});
app.get('/api/providers', async (req, res) => {
  const { category, query, available } = req.query;
  const models = await collections();
  const source = models.providers ? await models.providers.find().lean() : providers;
  const result = source.filter((provider) => {
    const verifiedMatch = provider.verified !== false;
    const categoryMatch = !category || category === 'All services' || provider.category === category;
    const queryMatch = !query || `${provider.name} ${provider.category} ${provider.location}`.toLowerCase().includes(query.toLowerCase());
    const availabilityMatch = available !== 'true' || provider.available;
    return verifiedMatch && categoryMatch && queryMatch && availabilityMatch;
  });
  res.json(result);
});

app.post('/api/auth/register', async (req, res) => {
  const { name, email, password, role, location, category } = req.body;
  if (!name || !email || !password || !['customer', 'provider', 'admin'].includes(role)) return res.status(400).json({ message: 'Complete all required fields.' });
  if (role === 'provider' && (!location?.trim() || !category?.trim())) return res.status(400).json({ message: 'Provider registration requires a service category and location.' });
  const models = await collections();
  const existingUser = models.users ? await models.users.findOne({ email: email.toLowerCase() }) : users.find((user) => user.email.toLowerCase() === email.toLowerCase());
  if (existingUser) return res.status(409).json({ message: 'An account with this email already exists.' });
  const idPrefix = role === 'customer' ? 'cus' : role === 'provider' ? 'pro' : 'adm';
  const user = { id: `${idPrefix}-${Date.now()}`, name, email, password, role, location: location || 'Dhaka', category: category || '', verified: role !== 'provider' };
  if (models.users) await models.users.create(user); else users.push(user);
  if (role === 'provider') {
    const providerProfile = { id: user.id, name, category: category || 'Electrician', location: location || 'Dhaka', rating: 0, experience: 'New provider', price: 'Price on request', available: false, initials: name.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase(), color: 'coral', verified: false, bio: 'Provider profile awaiting verification.' };
    if (models.providers) await models.providers.create(providerProfile); else providers.push(providerProfile);
  }
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, user.id);
  res.status(201).json({ token, user: publicUser(user) });
});
app.post('/api/auth/login', async (req, res) => {
  const { email, password, role } = req.body;
  const models = await collections();
  const user = models.users ? await models.users.findOne({ email: String(email).toLowerCase(), password, role }).lean() : users.find((item) => item.email.toLowerCase() === String(email).toLowerCase() && item.password === password && item.role === role);
  if (!user) return res.status(401).json({ message: 'Email, password, or role does not match.' });
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, user.id);
  res.json({ token, user: publicUser(user) });
});
app.get('/api/me', auth, (req, res) => res.json(publicUser(req.user)));
app.get('/api/provider/profile', auth, async (req, res) => {
  if (req.user.role !== 'provider') return res.status(403).json({ message: 'Provider access required.' });
  const models = await collections();
  const profile = models.providers ? await models.providers.findOne({ id: req.user.id }).lean() : providers.find((provider) => provider.id === req.user.id);
  if (!profile) return res.status(404).json({ message: 'Provider profile not found.' });
  res.json(profile);
});
app.patch('/api/provider/profile', auth, async (req, res) => {
  if (req.user.role !== 'provider') return res.status(403).json({ message: 'Provider access required.' });
  if (typeof req.body.available !== 'boolean') return res.status(400).json({ message: 'Availability must be true or false.' });
  if (req.user.verified !== true) return res.status(403).json({ message: 'Your provider profile must be approved by an admin before changing availability.' });
  const models = await collections();
  if (models.providers) {
    const profile = await Provider.findOneAndUpdate({ id: req.user.id }, { available: req.body.available }, { new: true }).lean();
    if (!profile) return res.status(404).json({ message: 'Provider profile not found.' });
    return res.json(profile);
  }
  const profile = providers.find((provider) => provider.id === req.user.id);
  if (!profile) return res.status(404).json({ message: 'Provider profile not found.' });
  profile.available = req.body.available;
  res.json(profile);
});

app.get('/api/bookings', auth, async (req, res) => {
  const models = await collections();
  const source = models.bookings ? await models.bookings.find().sort({ createdAt: -1 }).lean() : bookings;
  const visible = req.user.role === 'admin' ? source : source.filter((booking) => req.user.role === 'customer' ? booking.customerId === req.user.id : booking.providerId === req.user.id);
  res.json(visible);
});
app.post('/api/bookings', auth, async (req, res) => {
  if (req.user.role !== 'customer') return res.status(403).json({ message: 'Only customers can create bookings.' });
  const { providerId, date, time, location, details } = req.body;
  const models = await collections();
  const provider = models.providers ? await models.providers.findOne({ id: providerId }).lean() : providers.find((item) => item.id === providerId);
  if (!provider || !date || !time || !location) return res.status(400).json({ message: 'Choose a provider, date, time, and location.' });
  if (provider.verified !== true) return res.status(409).json({ message: 'This provider is awaiting admin approval.' });
  if (provider.available !== true) return res.status(409).json({ message: 'This provider is not accepting new bookings right now.' });
  const booking = { id: `BK-${Math.floor(1000 + Math.random() * 8999)}`, customerId: req.user.id, providerId, provider: provider.name, category: provider.category, date, time, location, details: details || '', status: 'Pending', amount: 0 };
  if (models.bookings) await models.bookings.create(booking); else bookings.unshift(booking);
  await addNotification({ recipientId: provider.id, actorId: req.user.id, type: 'booking_created', title: 'New booking request', message: req.user.name + ' requested ' + provider.category + ' service for ' + date + ' at ' + time + '.', entityId: booking.id });
  await notifyAdmins({ actorId: req.user.id, type: 'booking_created', title: 'New booking needs attention', message: provider.name + ' received a new ' + provider.category + ' booking from ' + req.user.name + '.', entityId: booking.id });
  res.status(201).json(booking);
});
app.patch('/api/bookings/:id', auth, async (req, res) => {
  const models = await collections();
  const booking = models.bookings ? await models.bookings.findOne({ id: req.params.id }) : bookings.find((item) => item.id === req.params.id);
  if (!booking) return res.status(404).json({ message: 'Booking not found.' });
  if (req.user.role === 'provider' && booking.providerId !== req.user.id) return res.status(403).json({ message: 'This booking is not assigned to you.' });
  if (req.user.role === 'customer' && booking.customerId !== req.user.id) return res.status(403).json({ message: 'This booking is not yours.' });
  const previousStatus = booking.status;
  const nextStatus = req.body.status || booking.status;
  const allowedStatuses = req.user.role === 'provider' ? ['Confirmed', 'Declined', 'Completed'] : req.user.role === 'admin' ? ['Confirmed', 'Declined', 'Completed', 'Cancelled'] : ['Cancelled'];
  if (!allowedStatuses.includes(nextStatus)) return res.status(400).json({ message: 'This status change is not allowed.' });
  booking.status = nextStatus;
  if (models.bookings) await booking.save();
  if (nextStatus !== previousStatus) {
    const statusMessage = nextStatus === 'Confirmed' ? booking.provider + ' accepted your ' + booking.category + ' booking.' : nextStatus === 'Declined' ? booking.provider + ' declined your ' + booking.category + ' booking.' : 'Booking ' + booking.id + ' is now ' + nextStatus.toLowerCase() + '.';
    const eventType = 'booking_' + nextStatus.toLowerCase();
    const eventTitle = 'Booking ' + nextStatus.toLowerCase();
    await addNotification({ recipientId: booking.customerId, actorId: req.user.id, type: eventType, title: eventTitle, message: statusMessage, entityId: booking.id });
    await addNotification({ recipientId: booking.providerId, actorId: req.user.id, type: eventType, title: eventTitle, message: statusMessage, entityId: booking.id });
    await notifyAdmins({ actorId: req.user.id, type: eventType, title: eventTitle, message: statusMessage, entityId: booking.id });
  }
  res.json(booking.toObject ? booking.toObject() : booking);
});
app.get('/api/admin/summary', auth, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Admin access required.' });
  const models = await collections();
  if (models.users) {
    const [customers, providerUsers, bookingCount, pending, categoryCount] = await Promise.all([User.countDocuments({ role: 'customer' }), User.countDocuments({ role: 'provider' }), Booking.countDocuments(), Booking.countDocuments({ status: 'Pending' }), Category.countDocuments()]);
    return res.json({ customers, providers: providerUsers, bookings: bookingCount, pending, categories: categoryCount });
  }
  res.json({ customers: users.filter((user) => user.role === 'customer').length, providers: users.filter((user) => user.role === 'provider').length, bookings: bookings.length, pending: bookings.filter((booking) => booking.status === 'Pending').length, categories: categories.length });
});
app.get('/api/admin/providers', auth, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Admin access required.' });
  const models = await collections();
  if (models.users) {
    const [providerUsers, profiles] = await Promise.all([User.find({ role: 'provider' }).select('-password').lean(), Provider.find().lean()]);
    return res.json(providerUsers.map((user) => ({ ...user, ...(profiles.find((profile) => profile.id === user.id) || {}) })));
  }
  res.json(users.filter((user) => user.role === 'provider').map((user) => ({ ...user, ...(providers.find((provider) => provider.id === user.id) || {}) })));
});
app.patch('/api/admin/providers/:id', auth, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ message: 'Admin access required.' });
  const { verified, available } = req.body;
  const models = await collections();
  if (models.users) {
    const user = await User.findOne({ id: req.params.id, role: 'provider' });
    const profile = await Provider.findOne({ id: req.params.id });
    if (!user || !profile) return res.status(404).json({ message: 'Provider profile not found.' });
    if (typeof verified === 'boolean') { user.verified = verified; profile.verified = verified; }
    if (typeof available === 'boolean') profile.available = available;
    await Promise.all([user.save(), profile.save()]);
    return res.json({ ...user.toObject(), ...profile.toObject(), password: undefined });
  }
  const user = users.find((item) => item.id === req.params.id && item.role === 'provider');
  const profile = providers.find((item) => item.id === req.params.id);
  if (!user || !profile) return res.status(404).json({ message: 'Provider profile not found.' });
  if (typeof verified === 'boolean') { user.verified = verified; profile.verified = verified; }
  if (typeof available === 'boolean') profile.available = available;
  res.json({ ...user, ...profile, password: undefined });
});

app.get('/api/notifications', auth, async (req, res) => {
  const models = await collections();
  const result = models.notifications ? await models.notifications.find({ recipientId: req.user.id }).sort({ createdAt: -1 }).limit(20).lean() : notifications.filter((item) => item.recipientId === req.user.id).slice(0, 20);
  res.json(result);
});
app.patch('/api/notifications/:id/read', auth, async (req, res) => {
  const models = await collections();
  if (models.notifications) return res.json(await models.notifications.findOneAndUpdate({ id: req.params.id, recipientId: req.user.id }, { read: true }, { new: true }).lean());
  const notification = notifications.find((item) => item.id === req.params.id && item.recipientId === req.user.id);
  if (!notification) return res.status(404).json({ message: 'Notification not found.' });
  notification.read = true;
  res.json(notification);
});
app.get('/api/reviews', auth, async (req, res) => {
  const models = await collections();
  const query = req.user.role === 'provider' ? { providerId: req.user.id } : req.user.role === 'customer' ? { customerId: req.user.id } : {};
  res.json(models.reviews ? await models.reviews.find(query).sort({ createdAt: -1 }).lean() : reviews.filter((review) => Object.entries(query).every(([key, value]) => review[key] === value)));
});
app.post('/api/reviews', auth, async (req, res) => {
  if (req.user.role !== 'customer') return res.status(403).json({ message: 'Only customers can submit reviews.' });
  const { bookingId, rating, comment } = req.body;
  if (!bookingId || !Number.isInteger(Number(rating)) || Number(rating) < 1 || Number(rating) > 5) return res.status(400).json({ message: 'Choose a rating from 1 to 5.' });
  const models = await collections();
  const booking = models.bookings ? await models.bookings.findOne({ id: bookingId }) : bookings.find((item) => item.id === bookingId);
  if (!booking || booking.customerId !== req.user.id) return res.status(404).json({ message: 'Completed booking not found.' });
  if (booking.status !== 'Completed') return res.status(409).json({ message: 'You can review a service after it is completed.' });
  const alreadyReviewed = models.reviews ? await models.reviews.findOne({ bookingId }) : reviews.find((review) => review.bookingId === bookingId);
  if (alreadyReviewed) return res.status(409).json({ message: 'This booking already has a review.' });
  const review = { id: `RV-${Date.now()}`, bookingId, customerId: req.user.id, customer: req.user.name, providerId: booking.providerId, rating: Number(rating), comment: String(comment || '').trim() };
  if (models.reviews) await models.reviews.create(review); else reviews.unshift(review);
  const providerReviews = models.reviews ? await models.reviews.find({ providerId: booking.providerId }).lean() : reviews.filter((item) => item.providerId === booking.providerId);
  const average = providerReviews.reduce((sum, item) => sum + item.rating, 0) / providerReviews.length;
  if (models.providers) await Provider.findOneAndUpdate({ id: booking.providerId }, { rating: Math.round(average * 10) / 10 }); else { const provider = providers.find((item) => item.id === booking.providerId); if (provider) provider.rating = Math.round(average * 10) / 10; }
  await addNotification({ recipientId: booking.providerId, actorId: req.user.id, type: 'review_received', title: 'New customer review', message: `${req.user.name} rated your ${booking.category} service ${rating}/5.`, entityId: bookingId });
  await notifyAdmins({ actorId: req.user.id, type: 'review_received', title: 'New review submitted', message: `${req.user.name} submitted a ${rating}/5 review for ${booking.provider}.`, entityId: bookingId });
  res.status(201).json(review);
});
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
connectDatabase().then(() => app.listen(PORT, () => console.log(`ShebaMate running at http://localhost:${PORT}`))).catch((error) => {
  console.error(`MongoDB connection failed: ${error.message}`);
  console.warn('Starting in demo memory mode. Check MONGODB_URI and MongoDB availability.');
  app.listen(PORT, () => console.log(`ShebaMate running at http://localhost:${PORT}`));
});
